# Vectis Semantic Search Engine - User Guide

## Overview

Vectis is a high-performance, standalone semantic search engine written in Rust. It combines traditional keyword search (BM25) with state-of-the-art vector search (HNSW) to provide accurate and context-aware search results.

This package contains a single executable `vectis` which functions as both the **Server** and the **CLI Client**.

## Installation

1.  **Download**: Extract the `vectis_deployment` folder to your desired location.
2.  **Requirements**:
    - macOS / Linux / Windows (WSL recommended)
    - No external database required (SQLite is embedded).
    - No external Python required (ONNX runtime is embedded).

## Quick Start

### 1. Start the Server

Open a terminal in the `vectis_deployment` folder and run:

```bash
./vectis serve
```

You should see:

```
🚀 Starting Vectis Server...
Listening on http://0.0.0.0:3000
```

Keep this terminal window open. The server must be running to handle requests.

### 2. Register a User (New Terminal)

Open a **new** terminal window (keep the server running in the first one).

```bash
./vectis register --username admin --password secret
```

Output:

```
✅ User 'admin' registered successfully!
```

### 3. Login

Login to get your authentication token.

```bash
./vectis login --username admin --password secret
```

Output:

```
✅ Login successful!
🔑 Token: eyJhbGciOiJIUzI1Ni...
(Save this token for upload/search commands)
```

**Copy the token string.** You will need it for the next steps.

### 4. Upload Documents

You can upload plain text files (`.txt`) or CSV files (`.csv`).

**Text Files:**
Create a text file to test (e.g., `test.txt`):

```bash
echo "Rust is a systems programming language that runs blazingly fast." > test.txt
```

**CSV Files (Product Data):**
Vectis automatically parses CSV files. Each row becomes a searchable document.
Example `products.csv`:

```csv
id,name,description,price
1,Gaming Laptop,High performance laptop with RTX 4090,2999.99
2,Mechanical Keyboard,Clicky switches and RGB lighting,129.99
```

Upload it using the token you copied:

```bash
./vectis upload --file test.txt --token "YOUR_TOKEN_HERE"
# OR
./vectis upload --file products.csv --token "YOUR_TOKEN_HERE"
```

Output:

```
✅ File uploaded successfully!
```

### 5. Search

Perform a semantic search. Even if keywords don't match exactly, the meaning will be captured.

```bash
./vectis search --query "fast system language" --token "YOUR_TOKEN_HERE"
```

Output:

```
🔍 Found 1 results:

1. test.txt (Score: 0.8521)
   Rust is a systems programming language that runs blazingly fast.
```

---

## CLI Command Reference

The `vectis` binary has several subcommands. You can always run `./vectis --help` to see them.

### `serve`

Starts the HTTP server.

- **Usage**: `./vectis serve`
- **Port**: Defaults to 3000.

### `register`

Creates a new user account.

- **Usage**: `./vectis register --username <USER> --password <PASS>`
- **Options**:
  - `--url`: Server URL (default: `http://localhost:3000`)

### `login`

Authenticates a user and returns a JWT token.

- **Usage**: `./vectis login --username <USER> --password <PASS>`
- **Options**:
  - `--url`: Server URL (default: `http://localhost:3000`)

### `upload`

Uploads a text file to the server for indexing.

- **Usage**: `./vectis upload --file <PATH> --token <TOKEN>`
- **Options**:
  - `--url`: Server URL (default: `http://localhost:3000`)

### `search`

Performs a hybrid semantic search.

- **Usage**: `./vectis search --query "<TEXT>" --token <TOKEN>`
- **Options**:
  - `--limit`: Max results (default: 10)
  - `--url`: Server URL (default: `http://localhost:3000`)

---

## Architecture & Performance

- **Hybrid Search**: Combines Tantivy (BM25) for keyword matching and HNSW (Hierarchical Navigable Small World) for vector similarity.
- **Embeddings**: Uses the `all-MiniLM-L6-v2` model via ONNX Runtime for generating vector embeddings locally.
- **Storage**:
  - Metadata & Users: SQLite (`vectis.db`)
  - Vector Index: HNSW binary file (`vectors.hnsw`)
  - Keyword Index: Tantivy directory (`index/`)
- **Concurrency**: Built on Tokio for asynchronous I/O and high throughput.

## Troubleshooting

- **"Connection refused"**: Ensure the server is running (`./vectis serve`) in a separate terminal.
- **"File not found"**: Check the path provided to the `--file` argument.
- **"Unauthorized"**: Ensure you are using the correct token from the `login` command. Tokens expire after 24 hours.
